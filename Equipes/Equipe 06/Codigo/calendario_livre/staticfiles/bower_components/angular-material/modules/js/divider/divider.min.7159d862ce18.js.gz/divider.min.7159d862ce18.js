/*!
 * AngularJS Material Design
 * https://github.com/angular/material
 * @license MIT
 * v1.1.3-master-471c225
 */
!function(i,e,n){"use strict";function r(i){return{restrict:"E",link:i}}r.$inject=["$mdTheming"],e.module("material.components.divider",["material.core"]).directive("mdDivider",r)}(window,window.angular);