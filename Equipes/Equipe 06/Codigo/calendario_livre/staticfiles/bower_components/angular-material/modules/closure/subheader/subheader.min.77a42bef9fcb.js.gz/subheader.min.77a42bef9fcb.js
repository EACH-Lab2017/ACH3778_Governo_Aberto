/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.11.3-master-3fe7d76
 */
function MdSubheaderDirective(e,a,r,n){return{restrict:"E",replace:!0,transclude:!0,template:'<div class="md-subheader">  <div class="md-subheader-inner">    <span class="md-subheader-content"></span>  </div></div>',link:function(t,i,d,c,o){function s(e){return angular.element(e[0].querySelector(".md-subheader-content"))}r(i);var u=i[0].outerHTML;o(t,function(e){s(i).append(e)}),i.hasClass("md-no-sticky")||o(t,function(r){var d='<div class="md-subheader-wrapper">'+u+"</div>",c=a(d)(t);e(t,i,c),n.nextTick(function(){s(c).append(r)})})}}}goog.provide("ng.material.components.subheader"),goog.require("ng.material.components.sticky"),goog.require("ng.material.core"),angular.module("material.components.subheader",["material.core","material.components.sticky"]).directive("mdSubheader",MdSubheaderDirective),MdSubheaderDirective.$inject=["$mdSticky","$compile","$mdTheming","$mdUtil"],ng.material.components.subheader=angular.module("material.components.subheader");