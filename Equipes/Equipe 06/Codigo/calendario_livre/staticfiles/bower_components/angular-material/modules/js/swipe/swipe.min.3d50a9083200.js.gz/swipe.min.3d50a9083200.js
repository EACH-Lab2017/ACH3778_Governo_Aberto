/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.11.3-master-3fe7d76
 */
!function(e,i,t){"use strict";function n(e){function i(e){function i(i,r,o){var c=e(o[t]);r.on(n,function(e){i.$apply(function(){c(i,{$event:e})})})}return{restrict:"A",link:i}}var t="md"+e,n="$md."+e.toLowerCase();return i.$inject=["$parse"],i}i.module("material.components.swipe",["material.core"]).directive("mdSwipeLeft",n("SwipeLeft")).directive("mdSwipeRight",n("SwipeRight"))}(window,window.angular);