/*!
 * AngularJS Material Design
 * https://github.com/angular/material
 * @license MIT
 * v1.1.3-master-471c225
 */
!function(t,n,e){"use strict";function r(){return{restrict:"AE",controller:o,controllerAs:"$ctrl",bindToController:!0}}function o(t){t.addClass("md-truncate")}o.$inject=["$element"],n.module("material.components.truncate",["material.core"]).directive("mdTruncate",r)}(window,window.angular);