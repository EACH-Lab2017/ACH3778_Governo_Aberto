/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.11.3-master-3fe7d76
 */
!function(t,n,i){"use strict";n.module("material.components.backdrop",["material.core"]).directive("mdBackdrop",["$mdTheming","$animate","$rootElement","$window","$log","$$rAF","$document",function(t,n,i,e,o,r,a){function p(p,d,s){var m=e.getComputedStyle(a[0].body);if("fixed"==m.position){var l=parseInt(m.height,10)+Math.abs(parseInt(m.top,10));d.css({height:l+"px"})}n.pin&&n.pin(d,i),r(function(){var n=d.parent()[0];if(n){var i=e.getComputedStyle(n);"static"==i.position&&o.warn(c)}t.inherit(d,d.parent())})}var c="<md-backdrop> may not work properly in a scrolled, static-positioned parent container.";return{restrict:"E",link:p}}])}(window,window.angular);