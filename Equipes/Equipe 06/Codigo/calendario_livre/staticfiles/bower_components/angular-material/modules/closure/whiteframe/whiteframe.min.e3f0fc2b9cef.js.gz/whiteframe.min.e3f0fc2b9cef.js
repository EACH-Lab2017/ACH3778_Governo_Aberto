/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.11.3-master-3fe7d76
 */
goog.provide("ng.material.components.whiteframe"),angular.module("material.components.whiteframe",[]),ng.material.components.whiteframe=angular.module("material.components.whiteframe");