/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.11.3-master-3fe7d76
 */
!function(n,t,e){"use strict";function i(n,e,i,o){function u(n){return t.isDefined(n.href)||t.isDefined(n.ngHref)||t.isDefined(n.ngLink)||t.isDefined(n.uiSref)}function a(n,t){return u(t)?'<a class="md-button" ng-transclude></a>':'<button class="md-button" ng-transclude></button>'}function c(a,c,s){var d=c[0];e(c),n.attach(a,c);var r=d.textContent.trim();r||i.expect(c,"aria-label"),u(s)&&t.isDefined(s.ngDisabled)&&a.$watch(s.ngDisabled,function(n){c.attr("tabindex",n?-1:0)}),c.on("click",function(n){s.disabled===!0&&(n.preventDefault(),n.stopImmediatePropagation())}),a.mouseActive=!1,c.on("mousedown",function(){a.mouseActive=!0,o(function(){a.mouseActive=!1},100)}).on("focus",function(){a.mouseActive===!1&&c.addClass("md-focused")}).on("blur",function(n){c.removeClass("md-focused")})}return{restrict:"EA",replace:!0,transclude:!0,template:a,link:c}}t.module("material.components.button",["material.core"]).directive("mdButton",i),i.$inject=["$mdButtonInkRipple","$mdTheming","$mdAria","$timeout"]}(window,window.angular);