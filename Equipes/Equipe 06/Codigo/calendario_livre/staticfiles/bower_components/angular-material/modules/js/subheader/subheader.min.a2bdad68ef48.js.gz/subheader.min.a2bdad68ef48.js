/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.11.3-master-3fe7d76
 */
!function(e,n,t){"use strict";function i(e,t,i,a){return{restrict:"E",replace:!0,transclude:!0,template:'<div class="md-subheader">  <div class="md-subheader-inner">    <span class="md-subheader-content"></span>  </div></div>',link:function(d,r,c,s,u){function o(e){return n.element(e[0].querySelector(".md-subheader-content"))}i(r);var m=r[0].outerHTML;u(d,function(e){o(r).append(e)}),r.hasClass("md-no-sticky")||u(d,function(n){var i='<div class="md-subheader-wrapper">'+m+"</div>",c=t(i)(d);e(d,r,c),a.nextTick(function(){o(c).append(n)})})}}}n.module("material.components.subheader",["material.core","material.components.sticky"]).directive("mdSubheader",i),i.$inject=["$mdSticky","$compile","$mdTheming","$mdUtil"]}(window,window.angular);