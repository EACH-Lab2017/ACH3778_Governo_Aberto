require('./dateparser');

var MODULE_NAME = 'ui.bootstrap.module.dateparser';

angular.module(MODULE_NAME, ['ui.bootstrap.dateparser']);

module.exports = MODULE_NAME;
