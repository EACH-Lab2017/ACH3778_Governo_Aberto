require('./tabindex');

var MODULE_NAME = 'ui.bootstrap.module.tabindex';

angular.module(MODULE_NAME, ['ui.bootstrap.tabindex']);

module.exports = MODULE_NAME;
