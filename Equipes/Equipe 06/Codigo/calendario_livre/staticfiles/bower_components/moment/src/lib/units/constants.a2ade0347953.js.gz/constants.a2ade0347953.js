export var YEAR = 0;
export var MONTH = 1;
export var DATE = 2;
export var HOUR = 3;
export var MINUTE = 4;
export var SECOND = 5;
export var MILLISECOND = 6;
